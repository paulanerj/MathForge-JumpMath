import { useEffect, useRef, useState } from 'react';
import { GameEngine } from './engine/GameEngine';
import { LevelSchema } from './types';

const THEMES = [
  { background: 'dark', skyColors: { top: '#080820', mid: '#040412', base: '#010108' }, palette: 'content' },
  { background: 'nebula', skyColors: { top: '#1a0820', mid: '#0d0412', base: '#050108' }, palette: 'content' },
  { background: 'void', skyColors: { top: '#000000', mid: '#080010', base: '#000000' }, palette: 'danger' },
  { background: 'frozen', skyColors: { top: '#082020', mid: '#041212', base: '#010808' }, palette: 'content' },
  { background: 'cyber', skyColors: { top: '#0a1a1a', mid: '#051010', base: '#020505' }, palette: 'content' }
];

const VECTORS = [
  { x: 0, y: -1 },
  { x: 0.2, y: -1 },
  { x: -0.2, y: -1 },
  { x: 0.5, y: -0.8 },
  { x: -0.5, y: -0.8 }
];

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<GameEngine | null>(null);
  
  const [gameState, setGameState] = useState<'config' | 'playing' | 'cleared'>('config');
  const [mathMode, setMathMode] = useState<'SUM_TO' | 'SKIP_COUNT'>('SUM_TO');
  const [targetsInput, setTargetsInput] = useState('10, 15, 20');
  const [playlist, setPlaylist] = useState<LevelSchema[]>([]);
  const [currentLevelIdx, setCurrentLevelIdx] = useState(0);

  useEffect(() => {
    if (!canvasRef.current || gameState === 'config') return;
    
    // Only instantiate once
    if (!engineRef.current) {
      engineRef.current = new GameEngine(canvasRef.current, playlist[0]);
      engineRef.current.audio.init();
      
      engineRef.current.onLevelComplete = () => {
         setGameState('cleared');
      };
    } else if (gameState === "playing") {
      // Re-load if playing a new level from config or cleared
      engineRef.current.loadSchema(playlist[currentLevelIdx]);
    }

    engineRef.current.start();

    const handleClick = (e: MouseEvent) => {
      if (gameState !== 'playing') return;
      engineRef.current?.handleInput(e.clientX, e.clientY);
    };
    
    window.addEventListener('click', handleClick);
    return () => {
      engineRef.current?.cleanup();
      window.removeEventListener('click', handleClick);
    };
  }, [gameState, currentLevelIdx]);

  const startMission = () => {
    const targets = targetsInput.split(',').map(s => parseInt(s.trim())).filter(n => !isNaN(n));
    if (targets.length === 0) return;

    const newPlaylist: LevelSchema[] = targets.map((target, i) => ({
      id: `dynamic_lvl_${i}`,
      mathConfig: mathMode === 'SUM_TO' ? { mode: 'SUM_TO', target } : { mode: 'SKIP_COUNT', step: target },
      progressionVector: VECTORS[i % VECTORS.length],
      theme: THEMES[i % THEMES.length]
    }));

    setPlaylist(newPlaylist);
    setCurrentLevelIdx(0);
    setGameState('playing');
    
    if (engineRef.current) {
       engineRef.current.audio.init();
    }
  };

  const proceedToNextSector = () => {
    if (currentLevelIdx + 1 < playlist.length) {
      setCurrentLevelIdx(prev => prev + 1);
      setGameState('playing');
    } else {
      setGameState('config');
    }
  };

  return (
    <div className="game-wrapper font-mono relative">
      
      {/* 1. MISSION CONFIG OVERLAY */}
      {gameState === 'config' && (
        <div className="absolute inset-0 bg-black/90 flex items-center justify-center z-50 p-6">
          <div className="max-w-md w-full bg-slate-800 border border-cyan-500/30 p-8 rounded-xl shadow-[0_0_50px_rgba(6,182,212,0.15)]">
            <h1 className="text-cyan-400 font-bold text-3xl mb-8 text-center tracking-widest uppercase">Mission Control</h1>
            
            <div className="space-y-6">
              <div>
                <label className="block text-slate-400 text-xs mb-2 uppercase tracking-tight">Operation Mode</label>
                <div className="flex bg-slate-900 p-1 rounded-lg border border-slate-700">
                  <button 
                    onClick={() => setMathMode('SUM_TO')}
                    className={`flex-1 py-2 px-4 rounded-md text-sm transition-all ${mathMode === 'SUM_TO' ? 'bg-cyan-500 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
                  >
                    SUM_TO
                  </button>
                  <button 
                    onClick={() => setMathMode('SKIP_COUNT')}
                    className={`flex-1 py-2 px-4 rounded-md text-sm transition-all ${mathMode === 'SKIP_COUNT' ? 'bg-magenta-500 bg-pink-600 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
                  >
                    SKIP_COUNT
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 text-xs mb-2 uppercase tracking-tight">Sequence Targets (CSV)</label>
                <input 
                  type="text" 
                  value={targetsInput}
                  onChange={(e) => setTargetsInput(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg py-3 px-4 text-cyan-200 focus:outline-none focus:border-cyan-500 transition-colors"
                  placeholder="10, 20, 30"
                />
              </div>

              <button 
                onClick={startMission}
                className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold py-4 rounded-lg shadow-xl transition-all transform active:scale-95 uppercase tracking-widest text-lg border-b-4 border-blue-800"
              >
                Launch Hyper-Jump
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2. SECTOR CLEARED OVERLAY */}
      {gameState === 'cleared' && (
        <div className="absolute inset-0 bg-cyan-900/40 backdrop-blur-sm flex items-center justify-center z-50 animate-in fade-in duration-500 p-6">
          <div className="text-center p-8 sm:p-12 bg-slate-900/90 border-2 border-cyan-400 rounded-2xl shadow-[0_0_80px_rgba(34,211,238,0.4)] w-full max-w-sm">
            <div className="text-cyan-400 text-4xl mb-4 font-bold tracking-tighter uppercase whitespace-normal">SECTOR CLEARED</div>
            <div className="text-white text-lg mb-8 opacity-80 whitespace-normal">Quantum Data Synchronized Successfully.</div>
            <button 
              onClick={proceedToNextSector}
              className="bg-cyan-500 text-slate-900 font-black py-4 px-6 rounded-full text-lg sm:text-xl w-full hover:bg-white hover:scale-105 transition-all shadow-2xl uppercase tracking-widest whitespace-normal"
            >
              Enter Next Dimension
            </button>
          </div>
        </div>
      )}

      <canvas 
        ref={canvasRef} 
        width={500} 
        height={800}
        className="cursor-crosshair shadow-[0_0_80px_rgba(34,211,238,0.15)] border border-slate-800" 
      />
    </div>
  );
}
