import { AudioConfig } from '../config/configTypes';
import { DEFAULT_ZYX_CONFIG } from '../config/defaults';

export class AudioEngine {
  ctx: AudioContext | null = null;
  droneGain: GainNode | null = null;
  lfo: OscillatorNode | null = null;
  osc1: OscillatorNode | null = null;
  osc2: OscillatorNode | null = null;
  noiseBuffer: AudioBuffer | null = null;
  config: AudioConfig;

  heartbeatTimer: number = 0;
  panicTickTimer: number = 0;

  musicState: {
    isPlaying: boolean;
    step: number;
    nextNoteTime: number;
    tempo: number;
    filterNode: BiquadFilterNode | null;
  } = { isPlaying: false, step: 0, nextNoteTime: 0, tempo: 130, filterNode: null };

  constructor(config: AudioConfig = DEFAULT_ZYX_CONFIG.audio) {
    this.config = config;
    this.musicState.tempo = config.defaultTempo;
  }

  init() {
    try {
      if (this.ctx) {
        if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
        return;
      }
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return; // Silent fail if entirely unsupported
      this.ctx = new AudioContextClass();
      
      // Generate white noise buffer for SFX
      const bufferSize = this.ctx.sampleRate * 2;
      this.noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = this.noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
          data[i] = Math.random() * 2 - 1;
      }
      this.startDrone();
    } catch (e) {
      console.warn("Audio Context initialization blocked or failed:", e);
    }
  }

  startDrone() {
    if (!this.ctx) return;
    try {
      this.stopDrone();
      
      const master = this.ctx.createGain();
      master.gain.value = this.config.masterDroneGain; // Ambient volume from config
      master.connect(this.ctx.destination);
      
      // 0.1Hz LFO for breathing effect
      this.lfo = this.ctx.createOscillator();
      this.lfo.frequency.value = 0.1; 
      const lfoGain = this.ctx.createGain();
      lfoGain.gain.value = 0.5;
      this.lfo.connect(lfoGain);

      this.droneGain = this.ctx.createGain();
      this.droneGain.gain.value = 0.5;
      lfoGain.connect(this.droneGain.gain);
      this.droneGain.connect(master);

      // Continuous deep space oscillators
      this.osc1 = this.ctx.createOscillator();
      this.osc1.type = 'sine';
      this.osc1.frequency.value = 65; 
      this.osc1.connect(this.droneGain);
      this.osc1.start();

      this.osc2 = this.ctx.createOscillator();
      this.osc2.type = 'square';
      this.osc2.frequency.value = 32.5; // Sub octave
      const f2 = this.ctx.createBiquadFilter();
      f2.type = 'lowpass';
      f2.frequency.value = 80;
      this.osc2.connect(f2);
      f2.connect(this.droneGain);
      this.osc2.start();

    } catch (e) {}
  }

  stopDrone() {
    try {
      if (this.osc1) { this.osc1.stop(); this.osc1.disconnect(); this.osc1 = null; }
      if (this.osc2) { this.osc2.stop(); this.osc2.disconnect(); this.osc2 = null; }
      if (this.lfo) { this.lfo.stop(); this.lfo.disconnect(); this.lfo = null; }
    } catch(e) {}
  }

  playJump() {
    if (!this.ctx) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const t = this.ctx.currentTime;
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(150, t);
      osc.frequency.exponentialRampToValueAtTime(600, t + 0.15);
      
      gain.gain.setValueAtTime(0.3, t);
      gain.gain.exponentialRampToValueAtTime(0.01, t + 0.15);
      
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      
      osc.start(t);
      osc.stop(t + 0.15);
    } catch(e) {}
  }

  playLand(isPerfect: boolean) {
    if (!this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      // Solid thump
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(120, t);
      osc.frequency.exponentialRampToValueAtTime(30, t + 0.1);
      gain.gain.setValueAtTime(0.4, t);
      gain.gain.exponentialRampToValueAtTime(0.01, t + 0.1);
      
      osc.connect(gain); gain.connect(this.ctx.destination);
      osc.start(t); osc.stop(t + 0.1);

      // Noise weight
      if (this.noiseBuffer) {
          const noise = this.ctx.createBufferSource();
          noise.buffer = this.noiseBuffer;
          
          const noiseFilter = this.ctx.createBiquadFilter();
          noiseFilter.type = 'lowpass';
          noiseFilter.frequency.value = 400;
          
          const noiseGain = this.ctx.createGain();
          noiseGain.gain.setValueAtTime(0.2, t);
          noiseGain.gain.exponentialRampToValueAtTime(0.01, t + 0.1);
          
          noise.connect(noiseFilter); noiseFilter.connect(noiseGain); noiseGain.connect(this.ctx.destination);
          noise.start(t); noise.stop(t + 0.1);
      }

      // Perfect Shimmer
      if (isPerfect) {
         const freqs = [523.25, 659.25, 783.99, 987.77]; // Cmaj7 arpeggio
         freqs.forEach((f, i) => {
            const arp = this.ctx!.createOscillator();
            const arpGain = this.ctx!.createGain();
            arp.type = 'sine';
            arp.frequency.value = f;
            arpGain.gain.setValueAtTime(0, t);
            arpGain.gain.linearRampToValueAtTime(0.1, t + i*0.04 + 0.01);
            arpGain.gain.exponentialRampToValueAtTime(0.001, t + i*0.04 + 0.3);
            arp.connect(arpGain); arpGain.connect(this.ctx!.destination);
            arp.start(t + i*0.04);
            arp.stop(t + i*0.04 + 0.3);
         });
      }
    } catch(e) {}
  }

  playDeath(type: string) {
    if (!this.ctx) return;
    try {
      this.stopDrone();
      const t = this.ctx.currentTime;
      
      if (type === 'ORBITAL_FREEZE') {
         for(let i=0; i<15; i++) {
            const osc = this.ctx.createOscillator();
            osc.type = Math.random() < 0.5 ? 'triangle' : 'square';
            osc.frequency.value = Math.random() * 2000 + 800;
            const g = this.ctx.createGain();
            g.gain.setValueAtTime(0.05, t);
            g.gain.exponentialRampToValueAtTime(0.01, t + 0.1 + Math.random()*0.4);
            osc.connect(g); g.connect(this.ctx.destination);
            osc.start(t); osc.stop(t + 0.5);
         }
      } else if (type === 'PLASMA_DISSOLVE' && this.noiseBuffer) {
         const noise = this.ctx.createBufferSource();
         noise.buffer = this.noiseBuffer;
         const filter = this.ctx.createBiquadFilter();
         filter.type = 'bandpass';
         filter.frequency.setValueAtTime(300, t);
         filter.frequency.exponentialRampToValueAtTime(2500, t + 0.6);
         const g = this.ctx.createGain();
         g.gain.setValueAtTime(0.5, t);
         g.gain.linearRampToValueAtTime(0, t + 0.6);
         noise.connect(filter); filter.connect(g); g.connect(this.ctx.destination);
         noise.start(t); noise.stop(t + 0.6);
      } else if (type === 'SINGULARITY_SIPHON') {
         const osc = this.ctx.createOscillator();
         const g = this.ctx.createGain();
         osc.frequency.setValueAtTime(800, t);
         osc.frequency.exponentialRampToValueAtTime(20, t + 0.5);
         g.gain.setValueAtTime(0.4, t);
         g.gain.linearRampToValueAtTime(0, t + 0.5);
         osc.connect(g); g.connect(this.ctx.destination);
         osc.start(t); osc.stop(t + 0.5);
      }
    } catch(e) {}
  }

  startMusic(tempo?: number) {
      if (!this.ctx || this.musicState.isPlaying) return;
      
      this.musicState.tempo = tempo ?? this.config.defaultTempo;
      this.musicState.isPlaying = true;
      this.musicState.step = 0;
      this.musicState.nextNoteTime = this.ctx.currentTime + 0.1;
      
      this.musicState.filterNode = this.ctx.createBiquadFilter();
      this.musicState.filterNode.type = 'lowpass';
      this.musicState.filterNode.frequency.value = this.config.filterFreqClosed; // Default closed
      
      // We pipe the music through a slight gain to prevent clipping with sound effects
      const masterGain = this.ctx.createGain();
      masterGain.gain.value = this.config.masterMusicGain;
      this.musicState.filterNode.connect(masterGain);
      masterGain.connect(this.ctx.destination);
  }

  stopMusic() {
      this.musicState.isPlaying = false;
      if (this.musicState.filterNode) {
          this.musicState.filterNode.disconnect();
          this.musicState.filterNode = null;
      }
  }

  _scheduleMusic() {
     if (!this.ctx || !this.musicState.isPlaying) return;
     const scheduleAheadTime = 0.1;
     
     while (this.musicState.nextNoteTime < this.ctx.currentTime + scheduleAheadTime) {
        this._playNote(this.musicState.step, this.musicState.nextNoteTime);
        const secondsPerBeat = 60.0 / this.musicState.tempo;
        this.musicState.nextNoteTime += secondsPerBeat * 0.25; // 16th notes
        this.musicState.step = (this.musicState.step + 1) % 16;
     }
  }

  _playNote(step: number, time: number) {
      if (!this.ctx || !this.musicState.filterNode) return;
      const pattern = [220, 0, 261.63, 0, 329.63, 220, 0, 261.63, 440, 0, 329.63, 261.63, 220, 0, 261.63, 329.63]; // A minor driving arpeggio
      const freq = pattern[step];
      if (freq === 0) return;

      const osc = this.ctx.createOscillator();
      const env = this.ctx.createGain();
      
      osc.type = 'sawtooth';
      osc.frequency.value = freq;
      
      env.gain.setValueAtTime(0, time);
      env.gain.linearRampToValueAtTime(0.15, time + 0.02);
      env.gain.exponentialRampToValueAtTime(0.001, time + 0.15);
      
      osc.connect(env);
      env.connect(this.musicState.filterNode);
      
      osc.start(time);
      osc.stop(time + 0.15);
  }

  update(dt: number, flowState: boolean, isPanic: boolean = false, mood: string = 'content') {
    if (!this.ctx) return;
    try {
      if (this.musicState.isPlaying) {
          this._scheduleMusic();
          if (this.musicState.filterNode) {
              const targetFreq = (mood === 'danger' || mood === 'critical')
                ? this.config.filterFreqPanic
                : (flowState ? this.config.filterFreqFlow : this.config.filterFreqClosed);
              const currentFreq = this.musicState.filterNode.frequency.value;
              // Smooth filter sweep
              this.musicState.filterNode.frequency.value = currentFreq + (targetFreq - currentFreq) * (dt * 5);
          }
      }

      if (flowState) {
          this.heartbeatTimer -= dt;
          if (this.heartbeatTimer <= 0) {
              this.heartbeatTimer = this.config.heartbeatInterval;
              
              const t = this.ctx.currentTime;
              const osc = this.ctx.createOscillator();
              const gain = this.ctx.createGain();
              osc.frequency.setValueAtTime(100, t);
              osc.frequency.exponentialRampToValueAtTime(40, t + 0.2);
              gain.gain.setValueAtTime(this.config.heartbeatGain, t);
              gain.gain.exponentialRampToValueAtTime(0.01, t + 0.2);
              osc.connect(gain); gain.connect(this.ctx.destination);
              osc.start(t); osc.stop(t + 0.2);
          }
      } else {
          this.heartbeatTimer = 0; // ready to fire instantly on flow entry
      }

      if (isPanic) {
          this.panicTickTimer -= dt;
          if (this.panicTickTimer <= 0) {
              this.panicTickTimer = this.config.panicTickInterval;
              const t = this.ctx.currentTime;
              // "Coconut/cowbell" ticking sound
              const osc = this.ctx.createOscillator();
              const gain = this.ctx.createGain();
              const filter = this.ctx.createBiquadFilter();
              
              osc.type = 'square';
              osc.frequency.setValueAtTime(800, t);
              osc.frequency.exponentialRampToValueAtTime(600, t + 0.03);
              
              filter.type = 'bandpass';
              filter.frequency.value = 1200;
              
              gain.gain.setValueAtTime(0.3, t);
              gain.gain.exponentialRampToValueAtTime(0.01, t + 0.03);
              
              osc.connect(filter);
              filter.connect(gain);
              gain.connect(this.ctx.destination);
              
              osc.start(t); 
              osc.stop(t + 0.03);
          }
      } else {
          this.panicTickTimer = 0;
      }

    } catch(e) {}
  }
}
