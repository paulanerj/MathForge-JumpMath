import { CatastropheConfig } from '../config/configTypes';
import { DEFAULT_ZYX_CONFIG } from '../config/defaults';
import { GameEngine } from './GameEngine';

export class MorticianAPI {
  type: string = '';
  deathComplete: boolean = false;
  config: CatastropheConfig;

  constructor(config: CatastropheConfig = DEFAULT_ZYX_CONFIG.catastrophe) {
    this.config = config;
  }

  init(type: string, engine: GameEngine) {
    this.type = type;
    this.deathComplete = false;

    const g = engine.state.zyx;
    g.jumping = false;
    g.falling = false;
    g.bouncing = false;

    if (type === 'void') {
      g.voidState = true;
      g.voidT = 0;
      g.voidAlpha = 1;
    } else if (type === 'wave') {
      g.waveState = true;
      g.waveT = 0;
      engine.state.timeScale = 1.0;
      if (!engine.state.wave) {
        engine.state.wave = { y: g.y, speed: 0, hit: false };
      }
    } else if (type === 'wormhole') {
      g.wormholeState = true;
      g.wormholeT = 0;
      engine.state.wormhole = { x: g.x, y: g.y - 30, r: 0, spin: 0, hit: false };
    } else if (type === 'detonation') {
      g.detonationState = true;
      g.detonationT = 0;
      g._detonated = false;
    } else if (type === 'orbital') {
      g.orbitalState = true;
      g.orbitalT = 0;
      engine.state.orbital = { targetX: g.x, hit: false };
    }
  }

  update(dt: number, engine: GameEngine) {
    if (this.deathComplete) return;

    const g = engine.state.zyx;
    const S = engine.state;

    if (this.type === 'void') {
      g.voidT! += dt * this.config.voidSpeed;
      g.sx = 1; g.sy = 1; // reset velocities
      
      if (g.voidT! < 0.17) {
        g.x += Math.sin(g.voidT! * 100) * 4.2;
        g.rot = Math.sin(g.voidT! * 120) * 0.18;
        S.shake = Math.max(S.shake, g.voidT! / 0.17 * 28);
      } else if (g.voidT! < 0.62) {
        const p = (g.voidT! - 0.17) / 0.45;
        const p2 = p * p;
        g.sx = Math.max(0.04, 1 - p2 * 0.98);
        g.sy = 1 + p * 1.8 - p2 * 2.2;
        g.rot = p2 * Math.PI * 1.5;
        g.y -= p2 * 5.5;
        S.shake = 12 + p * 8;
      } else if (g.voidT! < 0.80) {
        const p = (g.voidT! - 0.62) / 0.18;
        g.sx = Math.max(0.02, 0.04 - p * 0.02);
        g.sy = Math.max(0.02, (1 - p * 0.9) * 0.5);
        g.voidAlpha = Math.max(0, 1 - p * 1.4);
        S.shake = (1 - p) * 10;
      } else {
        g.voidAlpha = 0;
        S.shake = 0;
        // spawn particles if we had them
        if (g.voidT! > 1.0) this.deathComplete = true;
        
        if (g.voidAlpha === 0 && !g._detonated) {
           g._detonated = true;
           for (let i = 0; i < 48; i++) {
             engine.particles.push({
               x: g.x, y: g.y - 50,
               vx: (Math.random()-0.5)*600, vy: (Math.random()-0.5)*600,
               life: 1.6,
               sz: 3 + Math.random()*5,
               color: ['#ffffff','#cc88ff','#00d2ff'][Math.floor(Math.random()*3)]
             });
           }
        }
      }
    } else if (this.type === 'wave') {
      g.waveT! += dt;
      if (g.waveT! < 0.20) {
        S.timeScale = this.config.waveSlowdown1;
        g.rot = Math.sin(g.waveT! * 40) * 0.05;
      } else if (g.waveT! < 0.27) {
        S.timeScale = this.config.waveSlowdown2;
      } else if (!S.wave || !S.wave.hit) {
        if (S.wave) S.wave.hit = true;
        g.voidAlpha = 0;
        engine.fireImpact(5, 2, 10, 44);
        for (let i = 0; i < 44; i++) {
          engine.particles.push({
            x: g.x + (Math.random()-0.5)*40, y: g.y,
            vx: (Math.random()-0.5)*300, vy: -400 - Math.random()*400,
            life: 1.4,
            sz: 3 + Math.random()*5,
            color: Math.random() < 0.5 ? '#ffaa00' : '#ffffff'
          });
        }
      } else {
        S.timeScale = 1.0;
        if (g.waveT! > 1.30) this.deathComplete = true;
      }
    } else if (this.type === 'wormhole') {
      g.wormholeT! += dt;
      const wh = S.wormhole!;

      if (g.wormholeT! < 0.35) {
        const p = g.wormholeT! / 0.35;
        wh.r = p * 55;
        wh.spin += 0.22 + p * 0.30;
        g.rot = Math.sin(g.wormholeT! * 22) * 0.08;
        S.shake = Math.min(S.shake + 0.6, 10);
      } else if (g.wormholeT! < 0.95) {
        const p = (g.wormholeT! - 0.35) / 0.60;
        const p2 = p * p;
        wh.spin += 0.55;
        wh.r = 55 + Math.sin(p * Math.PI) * 18;
        const ang = p2 * Math.PI * 5;
        const rad = (1 - p2) * 46;
        g.x = wh.x + Math.cos(ang) * rad;
        g.y = wh.y + Math.sin(ang) * rad * 0.55;
        g.rot = ang;
        g.sx = Math.max(0.05, 1 - p2);
        g.sy = Math.max(0.05, 1 - p2);
        g.voidAlpha = Math.max(0, 1 - p2 * 1.1);
      } else if (!wh.hit) {
        wh.hit = true;
        g.voidAlpha = 0;
        engine.fireImpact(3, 1, 6, 26);
        for (let i = 0; i < 40; i++) {
          engine.particles.push({
            x: wh.x, y: wh.y,
            vx: (Math.random()-0.5)*500, vy: (Math.random()-0.5)*500,
            life: 1.5,
            sz: 2 + Math.random()*4,
            color: Math.random() < 0.5 ? '#aa66ff' : '#ffffff'
          });
        }
      } else {
        wh.r *= 0.82;
        wh.spin += 0.30;
        if (g.wormholeT! > 1.45) this.deathComplete = true;
      }
    } else if (this.type === 'detonation') {
      g.detonationT! += dt;
      if (g.detonationT! < 0.45) {
        const p = g.detonationT! / 0.45;
        g.sx = 1 + p * 0.55;
        g.sy = 1 + p * 0.55;
        g.x += (Math.random() - 0.5) * (1 + p * 6);
        S.shake = Math.min(S.shake + 0.4, 4 + p * 14);
      } else if (g.detonationT! < 0.52) {
        S.timeScale = 0.1;
        g.sx = 1.55; g.sy = 1.55;
      } else if (!g._detonated) {
        g._detonated = true;
        g.voidAlpha = 0;
        S.timeScale = 1.0;
        engine.fireImpact(6, 2, 12, 48);
        for (let i = 0; i < this.config.detonationParticles; i++) {
          engine.particles.push({
            x: g.x, y: g.y,
            vx: (Math.random()-0.5)*800, vy: (Math.random()-0.5)*800,
            life: 2.0,
            sz: 3 + Math.random()*5,
            color: ['#ffffff','#ffcc00','#ff6600','#ff2200'][Math.floor(Math.random()*4)]
          });
        }
      } else {
        if (g.detonationT! > 1.55) this.deathComplete = true;
      }
    } else if (this.type === 'orbital') {
      g.orbitalT! += dt;
      const orb = S.orbital!;

      if (g.orbitalT! < 0.6) {
        g.x += Math.random() * 4 - 2;
        g.rot = (Math.random() - 0.5) * 0.15;
        S.shake = Math.min(S.shake + 0.5, 12);
      } else if (!orb.hit) {
        orb.hit = true;
        g.voidAlpha = 0;
        engine.fireImpact(0, 0, 0, 50);
        for (let i = 0; i < 50; i++) {
          engine.particles.push({
            x: orb.targetX + (Math.random()-0.5)*60, y: g.y + (Math.random()-0.5)*80,
            vx: (Math.random()-0.5)*1500, vy: (Math.random()-0.5)*200,
            life: 1.4,
            sz: 4 + Math.random()*5,
            color: Math.random() < 0.5 ? '#ffffff' : '#00d2ff'
          });
        }
      } else {
        if (g.orbitalT! >= this.config.orbitalDuration) this.deathComplete = true;
      }
    }
  }

  drawDeath(ctx: CanvasRenderingContext2D, engine: GameEngine) {
    const S = engine.state;
    // Handled in Renderer.ts for most parts, but we can put some here if needed.
    // The SOT draws deaths directly in drawWorld using activeDeath().render()
    if (this.type === 'wormhole' && S.wormhole && S.wormhole.r > 0.5) {
      const wh = S.wormhole;
      ctx.save();
      ctx.translate(wh.x, wh.y);
      ctx.rotate(wh.spin);
      
      const halo = ctx.createRadialGradient(0, 0, wh.r * 0.25, 0, 0, wh.r * 1.9);
      halo.addColorStop(0,   'rgba(180,90,255,0.70)');
      halo.addColorStop(0.5, 'rgba(110,30,220,0.32)');
      halo.addColorStop(1,   'transparent');
      ctx.fillStyle = halo;
      ctx.beginPath(); ctx.ellipse(0, 0, wh.r * 1.9, wh.r * 1.1, 0, 0, Math.PI*2); ctx.fill();

      ctx.strokeStyle = 'rgba(220,160,255,0.85)';
      ctx.lineWidth = 2.5;
      for (let a = 0; a < 4; a++) {
        ctx.beginPath();
        for (let s = 0; s <= 24; s++) {
          const f  = s / 24;
          const th = a * Math.PI/2 + f * Math.PI * 1.6;
          const rr = wh.r * (1 - f * 0.92);
          const px = Math.cos(th) * rr, py = Math.sin(th) * rr * 0.58;
          s === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py);
        }
        ctx.stroke();
      }

      ctx.fillStyle = 'rgba(6,0,16,0.94)';
      ctx.beginPath(); ctx.ellipse(0, 0, wh.r * 0.30, wh.r * 0.17, 0, 0, Math.PI*2); ctx.fill();

      ctx.strokeStyle = 'rgba(255,200,255,0.9)';
      ctx.lineWidth = 1.6; ctx.shadowColor = '#cc66ff'; ctx.shadowBlur = 14;
      ctx.beginPath(); ctx.ellipse(0, 0, wh.r * 0.32, wh.r * 0.19, 0, 0, Math.PI*2); ctx.stroke();
      ctx.shadowBlur = 0;
      ctx.restore();
    }
  }
}
