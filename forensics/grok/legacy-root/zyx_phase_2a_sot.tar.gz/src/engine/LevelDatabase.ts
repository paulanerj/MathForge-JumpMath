import { LevelSchema } from '../types';

export const LEVEL_DATABASE: LevelSchema[] = [
  {
    id: 'level_1',
    mathConfig: { mode: 'SUM_TO', target: 10 },
    progressionVector: { x: 0, y: -1 },
    theme: { 
      background: 'dark', 
      skyColors: { top: '#080820', mid: '#040412', base: '#010108' },
      palette: 'content' 
    }
  },
  {
    id: 'level_2',
    mathConfig: { mode: 'SKIP_COUNT', step: 2 },
    progressionVector: { x: 0, y: -1 },
    theme: { 
      background: 'nebula', 
      skyColors: { top: '#1a0820', mid: '#0d0412', base: '#050108' },
      palette: 'content' 
    }
  },
  {
    id: 'level_3',
    mathConfig: { mode: 'SUM_TO', target: 20 },
    progressionVector: { x: 1, y: -1 }, // Diagonal!
    theme: { 
      background: 'void', 
      skyColors: { top: '#000000', mid: '#080010', base: '#000000' },
      palette: 'danger' 
    }
  },
  {
    id: 'level_4',
    mathConfig: { mode: 'SKIP_COUNT', step: 5 },
    progressionVector: { x: -1, y: -1 },
    theme: { 
      background: 'frozen', 
      skyColors: { top: '#082020', mid: '#041212', base: '#010808' },
      palette: 'content' 
    }
  }
];
