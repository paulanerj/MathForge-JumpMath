/**
 * Headless test environment mock for GameEngine
 */

export function setupHeadlessEnv() {
  // Mock 2D Context using Proxy
  const baseCtx: any = {
    measureText: (text: string) => ({ width: (text || '').length * 10 }),
    createLinearGradient: () => ({ addColorStop: () => {} }),
    createRadialGradient: () => ({ addColorStop: () => {} }),
    createPattern: () => ({}),
    getImageData: () => ({ data: new Uint8ClampedArray(4) }),
    getLineDash: () => [],
    setLineDash: () => {},
    fillStyle: '#000000',
    strokeStyle: '#000000',
    lineWidth: 1,
    font: '12px sans-serif',
    textAlign: 'center',
    textBaseline: 'middle',
    globalAlpha: 1.0,
    globalCompositeOperation: 'source-over',
    shadowColor: 'transparent',
    shadowBlur: 0,
    shadowOffsetX: 0,
    shadowOffsetY: 0,
    filter: 'none'
  };

  const dummyCtx: any = new Proxy(baseCtx, {
    get(target, prop) {
      if (prop in target) return target[prop];
      return () => {};
    },
    set(target, prop, value) {
      target[prop] = value;
      return true;
    }
  });

  // Mock Canvas
  class MockCanvas {
    width: number = 500;
    height: number = 800;
    rect = { left: 0, top: 0, width: 500, height: 800, right: 500, bottom: 800, x: 0, y: 0 };

    getContext(type: string) {
      if (type === '2d') return dummyCtx;
      return null;
    }

    getBoundingClientRect() {
      return this.rect;
    }

    setBoundingRect(left: number, top: number, width: number, height: number) {
      this.rect = { left, top, width, height, right: left + width, bottom: top + height, x: left, y: top };
    }
  }

  // Mock Audio Context
  class MockAudioNode {
    connect() {}
    disconnect() {}
    setValueAtTime() {}
    linearRampToValueAtTime() {}
    exponentialRampToValueAtTime() {}
    cancelScheduledValues() {}
    start() {}
    stop() {}
  }

  class MockAudioContext {
    state = 'running';
    sampleRate = 44100;
    currentTime = 0;

    createGain() {
      return {
        gain: {
          value: 1,
          setValueAtTime: () => {},
          linearRampToValueAtTime: () => {},
          exponentialRampToValueAtTime: () => {}
        },
        connect: () => {},
        disconnect: () => {}
      };
    }

    createOscillator() {
      return {
        type: 'sine',
        frequency: {
          value: 440,
          setValueAtTime: () => {},
          linearRampToValueAtTime: () => {},
          exponentialRampToValueAtTime: () => {}
        },
        connect: () => {},
        disconnect: () => {},
        start: () => {},
        stop: () => {}
      };
    }

    createBiquadFilter() {
      return {
        type: 'lowpass',
        frequency: {
          value: 1000,
          setValueAtTime: () => {},
          linearRampToValueAtTime: () => {},
          exponentialRampToValueAtTime: () => {}
        },
        Q: {
          value: 1,
          setValueAtTime: () => {},
          linearRampToValueAtTime: () => {},
          exponentialRampToValueAtTime: () => {}
        },
        connect: () => {},
        disconnect: () => {}
      };
    }

    createDelay() {
      return {
        delayTime: {
          value: 0,
          setValueAtTime: () => {},
          linearRampToValueAtTime: () => {}
        },
        connect: () => {},
        disconnect: () => {}
      };
    }

    createBuffer(channels: number, length: number, sampleRate: number) {
      return {
        channels,
        length,
        sampleRate,
        getChannelData: () => new Float32Array(length)
      };
    }

    createBufferSource() {
      return {
        buffer: null,
        loop: false,
        playbackRate: { value: 1 },
        connect: () => {},
        disconnect: () => {},
        start: () => {},
        stop: () => {}
      };
    }

    resume() {
      this.state = 'running';
      return Promise.resolve();
    }

    close() {
      this.state = 'closed';
      return Promise.resolve();
    }
  }

  // RAF Scheduler
  let nextFrameId = 1;
  const activeCallbacks = new Map<number, FrameRequestCallback>();

  function customRequestAnimationFrame(cb: FrameRequestCallback): number {
    const id = nextFrameId++;
    activeCallbacks.set(id, cb);
    return id;
  }

  function customCancelAnimationFrame(id: number): void {
    activeCallbacks.delete(id);
  }

  function stepRaf(timestamp: number = performance.now()) {
    const cbs = Array.from(activeCallbacks.entries());
    activeCallbacks.clear();
    for (const [id, cb] of cbs) {
      cb(timestamp);
    }
    return cbs.length;
  }

  function getActiveRafCount() {
    return activeCallbacks.size;
  }

  function clearAllRafs() {
    activeCallbacks.clear();
  }

  // Attach to globals
  const globalAny = globalThis as any;
  globalAny.HTMLCanvasElement = MockCanvas;
  globalAny.AudioContext = MockAudioContext;
  globalAny.requestAnimationFrame = customRequestAnimationFrame;
  globalAny.cancelAnimationFrame = customCancelAnimationFrame;
  if (!globalAny.window) {
    globalAny.window = globalAny;
  }

  return {
    MockCanvas,
    stepRaf,
    getActiveRafCount,
    clearAllRafs
  };
}
