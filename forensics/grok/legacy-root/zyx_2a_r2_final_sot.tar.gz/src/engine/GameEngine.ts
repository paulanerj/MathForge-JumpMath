import { GameState, LevelSchema, Platform } from '../types';
import { ZyxConfig, DEFAULT_ZYX_CONFIG } from '../config';
import { PlatformManager } from './PlatformManager';
import { Camera } from './Camera';
import { Renderer } from './Renderer';
import { MorticianAPI } from './MorticianAPI';
import { AudioEngine } from './AudioEngine';
import { PersonaController } from './PersonaController';
import { LEVEL_DATABASE } from './LevelDatabase';

export class GameEngine {
  config: ZyxConfig;
  state: GameState;
  platformManager: PlatformManager;
  camera: Camera;
  renderer: Renderer;
  mortician: MorticianAPI;
  audio: AudioEngine;
  persona: PersonaController;
  
  levelIndex: number = 0;
  correctInRow: number = 0;
  get WIN_CONDITION(): number {
    return this.config.gameplay.winCondition;
  }
  
  onLevelComplete?: () => void;

  targetPlatform: Platform | null = null;
  particles: any[] = [];
  lastTime: number = performance.now();
  animationFrameId: number | null = null;
  loopInstanceId: number = 0;

  start() {
    if (this.animationFrameId === null) {
      this.loopInstanceId++;
      console.log(`[GameEngine] start() called. Spawning loop instance ${this.loopInstanceId}`);
      this.lastTime = performance.now();
      this.animationFrameId = requestAnimationFrame(this.loop);
    }
  }
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;

  constructor(canvas: HTMLCanvasElement, initialSchema?: LevelSchema, config: ZyxConfig = DEFAULT_ZYX_CONFIG) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d')!;
    this.config = config;

    const schema = initialSchema || LEVEL_DATABASE[0];

    this.state = {
      status: 'playing',
      score: 0,
      activeLevelId: schema.id,
      timeLeft: this.config.gameplay.turnTimeLimit,
      kilonovaDist: 100,
      flowState: false,
      combo: 0,
      hitstop: 0,
      impactFlash: 0,
      chromaSplit: 0,
      shake: 0,
      timeScale: 1.0,
      schema: schema,
      zyx: {
        x: 0, y: 0,
        currentRow: 0,
        jumping: false,
        start: { x: 0, y: 0 },
        target: { x: 0, y: 0 },
        t: 0, sx: 1, sy: 1, rot: 0,
        val: 0, mood: 'content',
        trail: []
      }
    };

    this.platformManager = new PlatformManager(this.config.platform);
    this.camera = new Camera(this.config.camera);
    this.renderer = new Renderer(this.config);
    this.mortician = new MorticianAPI(this.config.catastrophe);
    this.audio = new AudioEngine(this.config.audio);
    this.persona = new PersonaController();

    this.init();
  }

  init() {
    this.state.zyx.val = this.platformManager.init(this.state.schema);
    this.state.timeLeft = this.config.gameplay.turnTimeLimit;
    this.start();
  }

  handleInput(clientX: number, clientY: number) {
    if (!this.audio.ctx || this.audio.ctx.state === 'suspended') {
       this.audio.init();
       this.audio.startMusic(this.config.audio.defaultTempo);
    }

    if (this.state.status === 'DYING') {
       return;
    }

    if (this.state.status === 'level_complete') {
        this.nextLevel();
        return;
    }

    const rect = this.canvas.getBoundingClientRect();
    const scaleX = 500 / rect.width;
    const scaleY = 800 / rect.height;

    const lx = (clientX - rect.left) * scaleX;
    const ly = (clientY - rect.top) * scaleY;

    const worldX = lx - this.canvas.width / 2 + this.camera.x;
    const worldY = ly - this.canvas.height / 2 + this.camera.y;

    const clickedPlatform = this.platformManager.platforms.find(p => {
      return Math.abs(p.x - worldX) < p.width / 2 && Math.abs(p.y - worldY) < p.height / 2;
    });

    if (clickedPlatform) {
      this.executeJump(clickedPlatform);
    }
  }

  executeJump(platform: Platform) {
    if (this.state.zyx.jumping || this.state.zyx.bouncing || this.state.zyx.falling || this.state.status !== 'playing') return;
    if (platform.rowIdx <= this.state.zyx.currentRow) return;

    this.persona.onJump(this.state.timeLeft);
    this.audio.playJump();

    this.targetPlatform = platform;
    this.state.zyx.jumping = true;
    this.state.zyx.start = { x: this.state.zyx.x, y: this.state.zyx.y };
    this.state.zyx.target = { x: platform.x, y: platform.y };
    this.state.zyx.t = 0;
    
    (this.state.zyx as any).prevX = this.state.zyx.x;
    (this.state.zyx as any).prevY = this.state.zyx.y;
  }

  clearDeathStates() {
    this.state.zyx.voidState = false;
    this.state.zyx.voidT = 0;
    this.state.zyx.voidAlpha = undefined;
    this.state.zyx.waveState = false;
    this.state.zyx.waveT = 0;
    this.state.zyx.wormholeState = false;
    this.state.zyx.wormholeT = 0;
    this.state.zyx.detonationState = false;
    this.state.zyx.detonationT = 0;
    this.state.zyx._detonated = false;
    this.state.zyx.orbitalState = false;
    this.state.zyx.orbitalT = 0;
    this.state.zyx.bouncing = false;
    this.state.zyx.falling = false;
    
    this.state.hitstop = 0;
    this.state.impactFlash = 0;
    this.state.chromaSplit = 0;
    this.state.shake = 0;
    this.state.timeScale = 1.0;
    if (this.state.wave) {
        this.state.wave.y = this.state.zyx.y + this.config.wave.spawnDistanceBehind;
        this.state.wave.hit = false;
    }
  }

  restart() {
    this.state.status = 'playing';
    this.state.score = 0;
    this.state.timeLeft = this.config.gameplay.turnTimeLimit;
    this.state.kilonovaDist = 100;
    this.state.combo = 0;
    this.correctInRow = 0;
    this.state.flowState = false;
    this.state.zyx.currentRow = 0;
    this.state.zyx.x = 0;
    this.state.zyx.y = 0;
    this.state.zyx.jumping = false;
    this.state.zyx.t = 0;
    this.state.zyx.sx = 1;
    this.state.zyx.sy = 1;
    this.state.zyx.rot = 0;
    this.state.zyx.mood = 'content';
    this.state.zyx.trail = [];
    this.state.zyx.targetAngle = undefined;
    this.state.zyx.bark = undefined;
    this.platformManager = new PlatformManager(this.config.platform);
    this.state.zyx.val = this.platformManager.init(this.state.schema);
    
    this.clearDeathStates();
    
    this.camera.x = 0;
    this.camera.y = 0;
    this.persona.reset();
    this.audio.startDrone();
    this.audio.startMusic(this.config.audio.defaultTempo);
  }

  respawn() {
    this.state.status = 'playing';
    this.state.timeLeft = this.config.gameplay.turnTimeLimit;
    this.state.combo = 0;
    this.correctInRow = 0;
    this.state.flowState = false;

    const safePlatform = this.platformManager.platforms.find(p => p.rowIdx === this.state.zyx.currentRow && p.isCorrect);
    if (safePlatform) {
        this.state.zyx.x = safePlatform.x;
        this.state.zyx.y = safePlatform.y;
    }
    
    this.state.zyx.jumping = false;
    this.state.zyx.t = 0;
    this.state.zyx.sx = 1;
    this.state.zyx.sy = 1;
    this.state.zyx.rot = 0;
    this.state.zyx.mood = 'content';
    this.state.zyx.targetAngle = undefined;
    this.state.zyx.bark = undefined;
    this.persona.reset();
    
    this.clearDeathStates();
    
    // Clean un-shatter future row
    this.platformManager.platforms.forEach(p => {
        if (p.rowIdx === this.state.zyx.currentRow + 1) {
            p.shattered = false;
            p.shards = [];
        }
    });

    this.audio.startMusic(this.config.audio.defaultTempo);
  }

  nextLevel() {
    if (this.onLevelComplete) {
       this.onLevelComplete();
    } else {
       // Fallback to internal database if no React hook is provided
       this.levelIndex = (this.levelIndex + 1) % LEVEL_DATABASE.length;
       this.loadSchema(LEVEL_DATABASE[this.levelIndex]);
    }
  }

  loadSchema(schema: LevelSchema) {
    this.state.schema = schema;
    this.state.activeLevelId = schema.id;
    this.restart();
  }

  triggerDeath(type: string | any) {
    this.state.status = 'DYING';
    this.state.deathType = type;
    this.state.zyx.mood = 'danger';
    this.state.combo = 0;
    this.state.flowState = false;
    this.audio.stopMusic();
    this.mortician.init(type, this);
    this.audio.playDeath(type);
  }

  fireImpact(hitstop: number, flash: number, chroma: number, shake: number) {
    this.state.hitstop = hitstop;
    this.state.impactFlash = flash;
    this.state.chromaSplit = chroma;
    this.state.shake = shake;
    this.state.timeScale = 1.0;
  }

  update(dt: number) {
    // Determine effective dt (timeScale)
    const effectiveDt = dt * (this.state.timeScale !== undefined ? this.state.timeScale : 1.0);
    
    if (this.state.hitstop > 0) {
      this.state.hitstop--;
      return;
    }

    if (this.state.impactFlash > 0) this.state.impactFlash--;
    if (this.state.chromaSplit > 0) this.state.chromaSplit = Math.max(0, this.state.chromaSplit - this.config.camera.chromaSplitDecay);
    if (this.state.shake > 0) this.state.shake *= this.config.camera.shakeDecay;
    
    // Wave updates
    if (this.state.wave && !this.state.wave.hit && this.state.status !== 'DYING') {
      this.state.wave.y -= this.state.wave.speed * effectiveDt;
      if (this.state.wave.y <= this.state.zyx.y + this.config.wave.proximityCollisionDist) {
        this.state.wave.hit = true;
        this.triggerDeath('wave');
      }
    }

    if (this.state.status === 'playing') {
      this.state.timeLeft -= effectiveDt;
      
      const zyx = this.state.zyx;

      // Calculate active flow state based on speed and combo
      if (this.state.combo >= this.config.flow.comboThreshold && this.state.timeLeft > this.config.flow.minTimeLeft) {
         this.state.flowState = true;
      } else if (this.state.timeLeft <= this.config.flow.minTimeLeft) {
         this.state.flowState = false;
      }

      // Calculate hint angle based STRICTLY on local jump timer
      const maxTime = this.config.gameplay.turnTimeLimit;
      const pct = this.state.timeLeft / maxTime;

      if (pct <= this.config.gameplay.hintTimeRatio) {
          const nextRowPlatforms = this.platformManager.platforms.filter(p => p.rowIdx === zyx.currentRow + 1);
          const targetPlatform = nextRowPlatforms.find(p => p.isCorrect);
          if (targetPlatform) {
              zyx.targetAngle = Math.atan2(targetPlatform.y - zyx.y, targetPlatform.x - zyx.x);
          }
      } else {
          zyx.targetAngle = undefined;
      }

      this.persona.update(dt, this);
      zyx.bark = this.persona.activeBark ? this.persona.activeBark.text : undefined;

      // Time-based mood (Cognitive Panic)
      if (this.persona.overrideMood) {
          zyx.mood = this.persona.overrideMood.mood;
      } else if (pct <= this.config.gameplay.moodCriticalRatio) {
          zyx.mood = 'critical';
      } else if (pct <= this.config.gameplay.moodDangerRatio) {
          zyx.mood = 'danger';
      } else {
          zyx.mood = 'content';
      }

      this.audio.update(dt, this.state.flowState, zyx.mood === 'critical', zyx.mood);

      this.state.kilonovaDist -= dt * this.config.gameplay.kilonovaDrainRate;

      if (this.state.timeLeft <= 0) {
         this.state.timeLeft = 0;
         const timerDeaths: any[] = ['void', 'wormhole', 'detonation', 'orbital'];
         this.triggerDeath(timerDeaths[Math.floor(Math.random() * timerDeaths.length)]);
         return;
      }

      let logicalY = zyx.y; 
      
      // Trail generation
      if (zyx.jumping || this.state.flowState) {
         zyx.trail.push({ x: zyx.x, y: zyx.y, life: 1.0, isFlow: this.state.flowState });
      }
      // Trail decay
      zyx.trail.forEach(t => { t.life -= dt * (this.state.flowState ? this.config.player.trailDecayFlow : this.config.player.trailDecayNormal); });
      zyx.trail = zyx.trail.filter(t => t.life > 0);

      if (zyx.jumping) {
        zyx.t += dt * this.config.jump.jumpSpeed; 

        let arcT;
        const kf1 = this.config.jump.arcKeyframe1;
        const kf2 = this.config.jump.arcKeyframe2;
        if (zyx.t < kf1) arcT = (zyx.t / kf1) * 0.5;
        else if (zyx.t < kf2) arcT = 0.5;
        else arcT = 0.5 + ((zyx.t - kf2) / (1.0 - kf2)) * 0.5;

        // Realtime squash & stretch transformation based on arc physics
        zyx.sy = 1 + Math.sin(arcT * Math.PI) * this.config.jump.squashY;
        zyx.sx = 1 - Math.sin(arcT * Math.PI) * this.config.jump.stretchX;

        if (zyx.t >= 1) {
          zyx.t = 1;
          zyx.jumping = false;
          zyx.x = zyx.target.x;
          zyx.y = zyx.target.y;
          this.handleLanding();
          logicalY = zyx.y;
          
          // Reset scale on land
          zyx.sx = 1;
          zyx.sy = 1;
        } else {
          zyx.x = zyx.start.x + (zyx.target.x - zyx.start.x) * zyx.t;
          logicalY = zyx.start.y + (zyx.target.y - zyx.start.y) * zyx.t;
          zyx.y = logicalY - Math.sin(arcT * Math.PI) * this.config.jump.apexHeight; 
        }
      } else if (zyx.bouncing) {
        const bHold = (zyx as any).bounceHold;
        if (bHold > 0) {
          (zyx as any).bounceHold--;
          logicalY = zyx.start.y;
        } else {
          (zyx as any).bounceT += dt / this.config.jump.bounceDuration;
          if ((zyx as any).bounceT >= 1) {
            zyx.bouncing = false;
            (zyx as any).bounceT = 0;
            zyx.x = zyx.target.x;
            zyx.y = zyx.target.y;
            zyx.sy = this.config.jump.bounceLandSy; zyx.sx = this.config.jump.bounceLandSx;
            zyx.rot = 0;
            this.state.timeLeft = this.config.gameplay.turnTimeLimit;
            logicalY = zyx.y;
          } else {
            const t = (zyx as any).bounceT;
            const ax = Math.sin(t * Math.PI);
            zyx.x = zyx.start.x + (zyx.target.x - zyx.start.x) * t;
            logicalY = zyx.start.y + (zyx.target.y - zyx.start.y) * t;
            zyx.y = logicalY - ax * this.config.jump.bounceApexHeight;
            zyx.rot = Math.sin(t * Math.PI * 2) * this.config.jump.bounceRotAmplitude;
            zyx.sy = 1 + ax * this.config.jump.bounceSquashY;
            zyx.sx = 1 - ax * this.config.jump.bounceStretchX;
          }
        }
      }

      const rawPv = this.state.schema.progressionVector;
      const mag = Math.hypot(rawPv.x, rawPv.y) || 1;
      const pv = { x: rawPv.x / mag, y: rawPv.y / mag };
      let targetTrackX = 0;
      if (pv.x !== 0) {
        const nextCenter = (zyx.currentRow + 1) * pv.x * this.platformManager.gapY;
        const currentZyxX = zyx.x;
        targetTrackX = 0.3 * currentZyxX + 0.7 * nextCenter;
      }
      this.camera.update(dt, targetTrackX, logicalY);

      // Prune platforms far behind the camera to prevent memory leaks
      if (this.platformManager.platforms.length > this.config.gameplay.platformPruneThreshold) {
          this.platformManager.platforms = this.platformManager.platforms.filter(p => {
              return p.rowIdx >= zyx.currentRow - this.config.gameplay.platformPruneRowsBehind;
          });
      }
      
      this.updateParticles(dt);
      
    } else if (this.state.status === 'DYING') {
      this.mortician.update(dt, this);
      this.updateParticles(dt);
      
      // Update shattered platforms
      if (this.targetPlatform?.shattered && this.targetPlatform.shards) {
          this.targetPlatform.shards.forEach(sh => {
              sh.x += sh.vx * dt;
              sh.y += sh.vy * dt;
              sh.vy += this.config.catastrophe.shardGravity * dt;
              sh.rot += sh.vrot * dt;
          });
      }
      
      // Auto-respawn when death animation finishes
      if (this.mortician.deathComplete) {
         if (this.state.kilonovaDist <= 0) {
             this.restart();
         } else {
             this.respawn();
         }
      }
      
    } else if (this.state.status === 'WARPING') {
      this.state.warpElapsed = (this.state.warpElapsed || 0) + dt * 1000;
      
      // Acceleration effect along progression vector
      const rawPv = this.state.schema.progressionVector;
      const mag = Math.hypot(rawPv.x, rawPv.y) || 1;
      const pv = { x: rawPv.x / mag, y: rawPv.y / mag };
      const warpStep = this.config.gameplay.warpAccelMultiplier * dt * (this.state.warpElapsed / 1000);
      this.camera.y += pv.y * warpStep;
      this.camera.x += pv.x * warpStep;
      
      this.updateParticles(dt);
      
      if (this.state.warpElapsed >= this.config.gameplay.warpDurationMs) {
          this.state.status = 'level_complete';
      }
    } else if (this.state.status === 'level_complete') {
        // Level complete pause or transition
    }
  }
  
  updateParticles(dt: number) {
    this.particles.forEach(pt => {
        pt.x += pt.vx * dt;
        pt.y += pt.vy * dt;
        pt.vy += this.config.player.particleGravity * dt;
        pt.life -= dt * this.config.player.particleLifeDecay;
    });
    this.particles = this.particles.filter(pt => pt.life > 0);
    
    this.platformManager.platforms.forEach(p => {
        if (p.impactTimer !== undefined && p.impactTimer > 0) {
            p.impactTimer -= dt;
        }
    });
  }

  handleLanding() {
    if (!this.targetPlatform) return;

    if (this.targetPlatform.isCorrect) {
      this.state.zyx.currentRow = this.targetPlatform.rowIdx;
      this.state.score++;
      this.state.combo++;
      this.correctInRow++;
      
      const isPerfect = this.state.timeLeft > this.config.flow.minTimeLeft;
      this.persona.onLand(true, isPerfect, this.state.combo);
      this.audio.playLand(isPerfect);
      
      // Perfect landing impact effect
      this.targetPlatform.impactTimer = this.config.platform.impactDuration;
      for (let i = 0; i < this.config.platform.impactParticleCount; i++) {
        this.particles.push({
          x: this.targetPlatform.x + (Math.random() - 0.5) * 80,
          y: this.targetPlatform.y - 10,
          vx: (Math.random() - 0.5) * 200,
          vy: Math.random() * -150 - 50,
          life: 0.5,
          color: '#00ffff',
          sz: Math.random() * 4 + 2
        });
      }

      if (this.correctInRow >= this.WIN_CONDITION) {
          this.state.status = 'WARPING';
          this.state.warpElapsed = 0;
          return;
      }

      this.state.timeLeft = this.config.gameplay.turnTimeLimit;
      this.state.kilonovaDist = Math.min(100, this.state.kilonovaDist + this.config.gameplay.kilonovaCorrectPush);
      this.state.zyx.val = this.targetPlatform.nextZyxVal!;
      this.platformManager.spawnRow(this.state.schema);
    } else {
      // Wrong platform decoy bounce back!
      this.state.combo = 0;
      this.state.flowState = false;
      this.state.kilonovaDist += this.config.gameplay.kilonovaWrongPenalty;
      
      const g = this.state.zyx;
      g.bouncing = true;
      (g as any).bounceT = 0;
      (g as any).bounceHold = this.config.jump.bounceHoldFrames;
      g.start = { x: g.x, y: g.y }; // bounce from
      
      const backX = (g as any).prevX !== undefined ? (g as any).prevX : this.canvas.width / 2;
      const backY = (g as any).prevY !== undefined ? (g as any).prevY : 720;
      
      g.target = { x: backX, y: backY - 15 };
    }
  }

  draw() {
    this.renderer.draw(this.ctx, this, this.canvas.width, this.canvas.height);
  }

  loop = (time: number) => {
    // Ownership verification for Phase 1A
    if (this.animationFrameId === null) {
      console.warn(`[GameEngine] Orphaned loop instance detected and prevented!`);
      return;
    }
    const dt = Math.min((time - this.lastTime) / 1000, this.config.gameplay.maxDeltaTime);
    this.lastTime = time;

    this.update(dt);
    this.draw();

    this.animationFrameId = requestAnimationFrame(this.loop);
  }

  cleanup() {
    console.log(`[GameEngine] cleanup() called. Terminating loop instance ${this.loopInstanceId}`);
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
  }
}
