import { PlatformConfig } from '../config/configTypes';
import { DEFAULT_ZYX_CONFIG } from '../config/defaults';
import { LevelSchema, Platform } from '../types';

export class PlatformManager {
  platforms: Platform[] = [];
  rowCursor: number = 1; // start spawning at row 1
  config: PlatformConfig;

  // Predicts the logical sequence of Zyx's progression even while pre-spawning rows ahead
  runningZyxVal: number = 0;

  constructor(config: PlatformConfig = DEFAULT_ZYX_CONFIG.platform) {
    this.config = config;
  }

  get gapY(): number {
    return this.config.gapY;
  }

  get gapX(): number {
    return this.config.gapX;
  }

  init(schema: LevelSchema): number {
    this.platforms = [];
    this.rowCursor = 1;

    // Seed the initial value for Zyx
    if (schema.mathConfig.mode === 'SUM_TO') {
      const target = schema.mathConfig.target || 10;
      this.runningZyxVal = Math.floor(Math.random() * (target - 1)) + 1; 
    } else {
      this.runningZyxVal = schema.mathConfig.step || 2; 
    }

    const initialVal = this.runningZyxVal;
    for (let i = 0; i < this.config.initialSpawnRows; i++) {
      this.spawnRow(schema);
    }
    return initialVal;
  }

  // Fisher-Yates shuffle
  private shuffleArray(array: number[]): number[] {
    const arr = [...array];
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }

  spawnRow(schema: LevelSchema) {
    const row = this.rowCursor;
    const rawPv = schema.progressionVector;
    const mag = Math.hypot(rawPv.x, rawPv.y) || 1;
    const pv = { x: rawPv.x / mag, y: rawPv.y / mag };
     
    const baseY = row * pv.y * this.gapY;
    const baseX = row * pv.x * this.gapY;
    
    const ox = -pv.y;
    const oy = pv.x;

    let correctAnswer: number;
    const decoys: number[] = [];
    let nextZyxVal: number;

    if (schema.mathConfig.mode === 'SUM_TO') {
      const target = schema.mathConfig.target || 10;
      correctAnswer = target - this.runningZyxVal;
      
      // Decoys CANNOT be correctAnswer and MUST be unique
      while (decoys.length < 2) {
        const dec = Math.floor(Math.random() * target * 1.5) + 1; // Slight overflow for plausible decoys
        if (dec !== correctAnswer && !decoys.includes(dec)) {
          decoys.push(dec);
        }
      }
      
      // Predict the value Zyx will have AFTER landing on this platform
      nextZyxVal = Math.floor(Math.random() * (target - 1)) + 1; 
    } else { // SKIP_COUNT
      const step = schema.mathConfig.step || 2;
      correctAnswer = this.runningZyxVal + step;
      
      while (decoys.length < 2) {
        // Create plausible decoys relative to the step sequence
        const multiplier = (Math.floor(Math.random() * 4) + 1) * (Math.random() > 0.5 ? 1 : -1);
        const dec = correctAnswer + multiplier * step;
        if (dec !== correctAnswer && !decoys.includes(dec) && dec > 0) {
          decoys.push(dec);
        }
      }

      // Zyx physically inherently adopts the platform number in skip counting
      nextZyxVal = correctAnswer;
    }

    const platformVals = [correctAnswer, decoys[0], decoys[1]];
    const shuffledVals = this.shuffleArray(platformVals);

    const pW = this.config.width;
    const pH = this.config.height;

    for (let i = 0; i < 3; i++) {
      const offset = i - 1; // -1, 0, 1 spread along orthogonal vector
      const px = baseX + ox * offset * this.gapX;
      const py = baseY + oy * offset * this.gapX;
      const val = shuffledVals[i];
      const isCorrect = val === correctAnswer;

      this.platforms.push({
        id: `r${row}_p${i}`,
        rowIdx: row,
        x: px,
        y: py,
        width: pW,
        height: pH,
        val,
        isCorrect,
        nextZyxVal: isCorrect ? nextZyxVal : undefined,
      });
    }

    // Advance the simulated machine tape
    this.runningZyxVal = nextZyxVal;
    this.rowCursor++;
  }
}
